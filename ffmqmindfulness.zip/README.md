# FFMQ-BR · Questionário de Mindfulness

Aplicação web do **Five Facet Mindfulness Questionnaire (FFMQ-BR)** — versão brasileira validada.

## Funcionalidades

- 39 questões com escala Likert 1–5
- Cálculo automático com inversão de scores (itens "R")
- Gráfico radar das 5 facetas
- Devolutiva gerada por IA (Claude)
- Download do relatório completo em HTML

## Rodar localmente

```bash
npm install
npm start
```

## Deploy no Vercel

1. Faça push deste repositório para o GitHub
2. Acesse [vercel.com](https://vercel.com) → New Project → importe o repo
3. Deixe as configurações padrão (detecta Create React App automaticamente)
4. Clique em **Deploy**

## Referências

- Baer et al. (2006). *Assessment*, 13, 27-45.
- Barros et al. (2014). *Psicologia: Teoria e Pesquisa*, 30(3), 317-327.
